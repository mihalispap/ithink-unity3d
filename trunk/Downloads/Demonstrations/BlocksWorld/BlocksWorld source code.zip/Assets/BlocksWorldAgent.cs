using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using iThinkLibrary.KnowledgeRepresentation;
using iThinkLibrary.iThinkActionManagerUtility;
using iThinkLibrary.iThinkPlannerUitility;
using iThinkLibrary.iThinkActionRepresentation;

public class BlocksWorldAgent : MonoBehaviour
{
    iThinkBrain brain;
    string actionName;
    bool[] stacks;
    string[] memory;
    
    //for GUI
    bool letsPlay;
    bool giveMeHint;
    bool resetEve;
    bool statistics;
    Vector2 vScrollValue = new Vector2();
    List<iThinkAction> actionList2;
    List<iThinkAction> actionList;

    public string[] schemaList = {
                                     "ActionBwPickUp-1-Tag::block",
                                     "ActionBwUnStack-2-Tag::block-Tag::block",
                                     "ActionBwPutDown-1-Tag::block",
                                     "ActionBwStack-2-Tag::block-Tag::block",
                                 };

    public void Awake()
    {
        brain = new iThinkBrain();

        // Sensing GameObjects
        List<String> tags = new List<String>();
        tags.Add( "block" );
        brain.sensorySystem.OmniscientUpdate( this.gameObject, tags );

        // Building knowledge
        initKnowledge();
        brain.curState = brain.startState;

        // Generate actions from knowledge
        brain.ActionManager = new iThinkActionManager();
        brain.ActionManager.initActionList( this.gameObject, schemaList, brain.getKnownObjects(), brain.getKnownFacts() );

        // Init search        
       
        repoFunct.loadData = false;
        repoFunct.completed = false;
        //brain.planner.forwardSearch( brain.startState, brain.goalState, brain.ActionManager );
    }
    
    public void Start()
    {
    	letsPlay = false;
    	giveMeHint = false;
    	resetEve = false;
    	statistics = false;
    }
    
    void OnGUI()
    { 
    	var evt = Event.current;
    	GUI.Box(new Rect(0,0,325,65),"Menu");
    	if(giveMeHint == false){
    		if(GUI.Button(new Rect(5,20,100,40),"Show Plan"))
    			giveMeHint = true;
    	}
    	else {
    		if(GUI.Button(new Rect(5,20,100,40),"Hide Plan"))
    			giveMeHint = false;
    	}
    	
    	if(letsPlay == false){
    		if(GUI.Button(new Rect(115,20,100,40),"Run Plan")){
				letsPlay = true;
    			
    		}
    	}else{
    		if(GUI.Button(new Rect(115,20,100,40),"Stop"))
				letsPlay = false;
    	}
    
    	if(resetEve == false){
    		if(GUI.Button(new Rect(220,20,100,40),"Solve Plan")){
				resetEve = true;	
    		}
    	}
    	
    	GUI.Box(new Rect(800,0,100,230),"Initial State");
    	printState(brain.startState,5);
    	
    	GUI.Box(new Rect(910,0,100,230),"Goal State");
    	printState(brain.goalState,115);
    	
    	if(giveMeHint == true){
    		vScrollValue = GUI.BeginScrollView(new Rect(0,70,216,300),vScrollValue,new Rect(0,0,200,700));
	    	//if(evt.type == EventType.Repaint ){
    		 	showPlan();
	    	//}	
    		GUI.EndScrollView();
    	}
    	
    	if(statistics == true)
    	{
    		printStats();
    	}
    }
	
    void printStats()
    {
    	GUI.Box(new Rect(230,70,140,210),"Planning Statistics");
    	string str = "Total Actions : "+brain.planner.totalActions;
    	GUI.Label(new Rect(240,100,120,30),str);
    	str = "Applicable : "+brain.planner.totalApplicable;
    	GUI.Label(new Rect(240,120,120,30),str);
    	str = "Actually used : "+brain.planner.totalActionsUsed;
    	GUI.Label(new Rect(240,140,120,30),str);
    	str = "Total nodes : "+brain.planner.nodes;
    	GUI.Label(new Rect(240,180,120,30),str);
    	str = "Expanded : "+brain.planner.nodesExpanded;
    	GUI.Label(new Rect(240,200,120,30),str);
    	str = "Plan Lenght : "+brain.planner.getPlan().getPlanActions().Count;
    	GUI.Label(new Rect(240,230,120,30),str);
    }
    
    void printState(iThinkState state,int step)
    {
    	int i=0;
    	string testSt = "";
    	foreach(iThinkFact fact in state.getFactList())
    	{

    		switch(fact.getName())
    		{
    			case "on":
    				testSt = fact.getObj(0).name+ " on " + fact.getObj(1).name;
    				GUI.Label(new Rect(800+step,20+i,200,30),testSt);
    				break;
    			case "onTable":
    				testSt = "onTable " + fact.getObj(0).name;
    				GUI.Label(new Rect(800+step,20+i,200,30),testSt);
    				break;
    			case "holding":
    				testSt = "holding " + fact.getObj(0).name;
    				GUI.Label(new Rect(800+step,20+i,200,30),testSt);
    				break;
    		}
    		i+=30;
    		testSt="";
    	}
    }
    
    void showPlan()
    {
    	
    	int i=0;
    	int Counter=1;
    	int TotalActions = actionList2.Count;
    	string lal=null;
    	iThinkFact obj=null;
    	
    	GUIStyle style  =  new GUIStyle();
    	
    	GUI.Box(new Rect(0,0,200,700),"");
    	
    	foreach (iThinkAction action in actionList2) {
    		switch(action.getName())
    		{
    			case "PickUp":
    				obj = action.getPreconditions().Find(
    				delegate(iThinkFact fact)
    				{
    					return fact.getName().Equals("onTable");
    					
    				}	);
    				
    				if(obj !=null)
    					lal = "Action No"+ Counter +" : PickUp "+obj.getObj(0).name.ToString();
    				break;
    			case "PutDown":
    				obj = action.getPreconditions().Find(
    				delegate(iThinkFact fact)
    				{
    					return fact.getName().Equals("holding");
    					
    				}	);
    				
    				if(obj !=null)
    					lal = "Action No"+ Counter +" : PutDown "+obj.getObj(0).name.ToString();
    				break;
    			case "Stack":
    				obj = action.getEffects().Find(
    				delegate(iThinkFact fact)
    				{
    					return fact.getName().Equals("on");
    					
    				}	);
    				
    				if(obj !=null)
    					lal = "Action No"+ Counter +" : Stack "+obj.getObj(0).name.ToString()+" to "+obj.getObj(1).name.ToString();
    				break;
    			case "UnStack":
    				obj = action.getPreconditions().Find(
    				delegate(iThinkFact fact)
    				{
    					return fact.getName().Equals("on");
    					
    				}	);
    				
    				if(obj !=null)
    					lal = "Action No"+ Counter +" : UnStack "+obj.getObj(0).name.ToString()+" from "+obj.getObj(1).name.ToString();
    				break;
    		}
    		
    		if(obj!=null)
    		{
    			iThinkAction actio = actionList.Find(
    					delegate(iThinkAction a){
    						
    						return a.Equals(action) ;
    						
    					});
    			
    			if(actio == null){
    				style.normal.textColor = Color.red;
    				GUI.Label(new Rect(0,0+i,200,200),lal,style);
    			}
    			else{
    				if(actionList.Count < actionList2.Count-Counter+1){
    					style.normal.textColor = Color.red;
    					GUI.Label(new Rect(0,0+i,200,200),lal,style);
    				}
    				else{
    					style.normal.textColor = Color.yellow;
    					GUI.Label(new Rect(0,0+i,200,200),lal,style);
    				}
    			}
    		}
    		i+=30;
    		Counter++;
    		lal= null;
    		
    	}
    	
    }
    
    public void Update()
    {	
        
    	if ( Time.time - brain.lastUpdate >= 0.3 && repoFunct.completed )
        {
        	if(letsPlay){
	        	 if ( actionList.Count != 0 )
	                applyNextAction();
	            brain.lastUpdate = Time.time;
	            renderCurrentState();
        	}
    	}else{
    		if(resetEve == true){
	    		if(!repoFunct.completed){
		        	brain.planner.forwardSearch( brain.startState, brain.goalState, brain.ActionManager );
		        	if(repoFunct.completed){
		        		stacks = new bool[brain.getKnownObjects().Count];
		        		 memory = new string[brain.getKnownObjects().Count];
		        		 for(int i=0;i<brain.getKnownObjects().Count;i++){
		        		 	stacks[i]=false;
		        		 	memory[i] = null;
		        		 }
		        		 actionList2 = new List<iThinkAction>(brain.planner.getPlan().getPlanActions());
		        		 actionList = new List<iThinkAction>(brain.planner.getPlan().getPlanActions());
		        		 renderCurrentState();
		        	}
	    		}
    			resetEve = false;
    			statistics = true;
    		}
        }
    }

    private void renderCurrentState()
    {
        int i;

        foreach ( iThinkFact fact in brain.curState.getFactList() )
        {
            if ( fact.getName().Equals( "onTable" ) )
            {
            	i = findStack(fact.getObj( 0 ).name);
                fact.getObj( 0 ).transform.position = new Vector3( (float)( 1.5 - i * 1.5 ), 0, 0 );
                stacks[i] = true;
                memory[i] = fact.getObj( 0 ).name.ToString();
            }
        }
	
        foreach ( iThinkFact fact in brain.curState.getFactList() )
        {
            if ( fact.getName().Equals( "on" ) )
            {
                fact.getObj( 0 ).transform.position = fact.getObj( 1 ).transform.position;
                fact.getObj( 0 ).transform.Translate( 0, (float)1.5, 0 );
            }

            else if ( fact.getName().Equals( "holding" ) )
            {
                fact.getObj( 0 ).transform.position = new Vector3( -8, 5, 0 );
                if(actionName.Equals("PickUp")){
                	i = findStack(fact.getObj( 0 ).name);
                	stacks[i]= false ;
                	memory[i] = null;	
                }
            }
        }

    }
    
    int findStack(string name)
    {
    	for(int i=0;i<brain.getKnownObjects().Count;i++){
    		if(memory[i]!=null && memory[i].Equals(name))
    			return i;
    	}
    	
    	return findNextFreeStack( );
    }
    
    int findNextFreeStack( )
    {	
    	int i=0;
        for(i=0;i<brain.getKnownObjects().Count;i++)
        {
        	if ( !stacks[i] )
                return i;
        }
        return i;
    }
    
    void applyNextAction()
    {
    	if(actionList.Count!=0){
        	brain.curState = new iThinkState( actionList[0].applyEffects( brain.curState ) );
        	actionName = actionList[0].getName();
        	actionList.RemoveAt( 0 );
    	}
    }

    void initKnowledge()
    {
        ///////////////////////////
        // Building current state//
        ///////////////////////////
        List<iThinkFact> factList = new List<iThinkFact>();
        factList.Add( new iThinkFact( "onTable", GameObject.Find( "E" ) ) );
        factList.Add( new iThinkFact( "onTable", GameObject.Find( "D" ) ) );
        factList.Add( new iThinkFact( "onTable", GameObject.Find( "C" ) ) );
        factList.Add( new iThinkFact( "onTable", GameObject.Find( "F" ) ) );
        factList.Add( new iThinkFact( "on", GameObject.Find( "A" ), GameObject.Find( "E" ) ) );
        factList.Add( new iThinkFact( "on", GameObject.Find( "B" ), GameObject.Find( "D" ) ) );
        factList.Add( new iThinkFact( "on", GameObject.Find( "G" ), GameObject.Find( "F" ) ) );
        factList.Add( new iThinkFact( "clear", GameObject.Find( "A" ) ) );
        factList.Add( new iThinkFact( "clear", GameObject.Find( "B" ) ) );
        factList.Add( new iThinkFact( "clear", GameObject.Find( "C" ) ) );
        factList.Add( new iThinkFact( "clear", GameObject.Find( "G" ) ) );
        factList.Add( new iThinkFact( "gripEmpty" ) );
        brain.startState = new iThinkState( "Initial", new List<iThinkFact>( factList ) );

        /////////////////
        // Create goal //
        /////////////////
        factList.Clear();
        factList.Add( new iThinkFact( "on", GameObject.Find( "E" ), GameObject.Find( "A" ) ) );
        factList.Add( new iThinkFact( "on", GameObject.Find( "D" ), GameObject.Find( "F" ) ) );
        factList.Add( new iThinkFact( "on", GameObject.Find( "C" ), GameObject.Find( "B" ) ) );
        factList.Add( new iThinkFact( "on", GameObject.Find( "F" ), GameObject.Find( "E" ) ) );
        factList.Add( new iThinkFact( "holding", GameObject.Find( "G" ) ) );

        brain.goalState = new iThinkState( "Goal", new List<iThinkFact>( factList ) );
    }
}
